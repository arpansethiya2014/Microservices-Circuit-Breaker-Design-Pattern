package com.arpan.model;

import lombok.Data;

@Data
public class Failure {
    private final String msg;
}
