//package com.arpan.model;
//
//public interface Type {
//}
