package com.arpan.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.arpan.dto.AddressDTO;
import com.arpan.model.Failure;
import com.arpan.model.Order;
import com.arpan.repository.OrderRepository;
import com.arpan.service.OrderService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private RestTemplate restTemplate;
	private static final String SERVICE_NAME = "order-service";
	private static final String ADDRESS_SERVICE_URL = "http://localhost:8081/addresses/";

	@CircuitBreaker(name = SERVICE_NAME, fallbackMethod = "fallbackMethod")
	public Object findOrder(String orderNumber) {
		Optional<Order> orderOptional = orderRepository.findByOrderNumber(orderNumber);

		if (orderOptional.isEmpty()) { // First, check if order exists
			// throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Order with ID " +
			// orderNumber + " not found");
			Map<String, String> map = new HashMap<>();
			map.put("Description", "Order with ID " + orderNumber + " not found");
			return map;
		}

		Order order = orderOptional.get(); // Now, it's safe to call .get()

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<AddressDTO> entity = new HttpEntity<>(null, headers);

		ResponseEntity<AddressDTO> response = restTemplate.exchange(ADDRESS_SERVICE_URL + order.getPostalCode(),
				HttpMethod.GET, entity, AddressDTO.class);

		AddressDTO addressDTO = response.getBody();
		if (addressDTO != null) {
			order.setShippingState(addressDTO.getState());
			order.setShippingCity(addressDTO.getCity());
		}

		return order;
	}

	private Object fallbackMethod(Exception e) {
		return new Failure("Service is not responding properly");
	}
}
