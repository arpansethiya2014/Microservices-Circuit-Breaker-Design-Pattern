package com.arpan.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.arpan.model.Order;
import com.arpan.repository.OrderRepository;

import jakarta.annotation.PostConstruct;

@Configuration
public class DataSetup {
    @Autowired
    private OrderRepository orderRepository;
    @PostConstruct
    public void setupData() {
        orderRepository.saveAll(Arrays.asList(
                Order.builder().id(1).orderNumber("100").postalCode("452005").build(),
                Order.builder().id(2).orderNumber("101").postalCode("452006").build(),
                Order.builder().id(3).orderNumber("102").postalCode("452007").build()));
    }
}
