package com.arpan.service;

public interface OrderService {
    Object findOrder(String orderNumber);
}
