package com.arpan.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.arpan.model.Address;
import com.arpan.repository.AddressRepository;

import jakarta.annotation.PostConstruct;

@Configuration
public class DataSetup {
    @Autowired
    private AddressRepository addressRepository;
    @PostConstruct
    public void setupData() {
        addressRepository.saveAll(Arrays.asList(
                Address.builder().id(1).postalCode("452005").state("India").city("Indore")
                        .build(),
                Address.builder().id(2).postalCode("452006").state("India").city("Bhopal").build(),
                Address.builder().id(3).postalCode("452007").state("India").city("Ratlam")
                        .build()));
    }
}
