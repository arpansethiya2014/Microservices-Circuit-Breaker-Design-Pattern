package com.arpan.service;

import com.arpan.model.Address;

public interface AddressService {
    Address getAddressByPostalCode(String postalCode);
}
